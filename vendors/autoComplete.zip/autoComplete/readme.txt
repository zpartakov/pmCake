Auto Completer - V1.0 (19/09/2007).
Jamie McConnell, jamie@blue44.com.

Please visit Nodstrum.com for any information relating to this script.
Nodstrum and/or Jamie McConnell cannot be held responsible for any problems that arise after installing or using this script.

MIT License.