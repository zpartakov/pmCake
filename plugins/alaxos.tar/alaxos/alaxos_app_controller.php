<?php

class AlaxosAppController extends AppController {

}

?>