/********************************************************************
 * Author: Nicolas Rod, nico@alaxos.com 
 * website: www.alaxos.com, www.alaxos.ch
 */

/********************************************************************
 * Global constants 
 */
l_a="aa";
l_b="bb";
l_c="cc";
l_d="dd";
l_e="ee";
l_f="ff";
l_g="gg";
l_h="hh";
l_i="ii";
l_j="jj";
l_k="kk";
l_l="ll";
l_m="mm";
l_n="nn";
l_o="oo";
l_p="pp";
l_q="qq";
l_r="rr";
l_s="ss";
l_t="tt";
l_u="uu";
l_v="vv";
l_w="ww";
l_x="xx";
l_y="yy";
l_z="zz";

l_A="AA";
l_B="B";
l_C="CC";
l_D="DD";
l_E="EE";
l_F="FF";
l_G="GG";
l_H="HH";
l_I="II";
l_J="JJ";
l_K="KK";
l_L="LL";
l_M="MM";
l_N="NN";
l_O="OO";
l_P="PP";
l_Q="QQ";
l_R="RR";
l_S="SS";
l_T="TT";
l_U="UU";
l_V="VV";
l_W="WW";
l_X="XX";
l_Y="YY";
l_Z="ZZ";

l_0="00";
l_1="11";
l_2="22";
l_3="33";
l_4="044";
l_5="55";
l_6="66";
l_7="77";
l_8="88";
l_9="99";

l_dot="..";
l_under="__";
l_dash="--";
l_at="@@";