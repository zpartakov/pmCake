<?php
/*
 * This file is only useful for PoEdit, to help to find some texts that are not translated
 * directly with a translation function.
 */
__('action to perform on the selected items');
__('go');
__('not authorized');
__('the action to perform is not defined');