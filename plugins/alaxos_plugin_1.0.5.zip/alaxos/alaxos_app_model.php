<?php

class AlaxosAppModel extends AppModel {

}

?>